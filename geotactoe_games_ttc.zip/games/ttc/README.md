# GeoTacToe (Geocaching Tic-Tac-Toe)

- Modes: 1P vs Computer, or 2 Players
- Difficulty: Easy (random), Normal (win/block/center/corners), Hard (minimax perfect play)
- Mobile-friendly CSS grid, square cells via aspect-ratio
- Theme images: SVG cache (X) and GPS pin (O)

Open `games/ttc/index.html` to play.
Generated 2025-08-11T23:51:39.055779Z
