(()=>{
  const boardEl=document.getElementById('board');
  const cells=[...boardEl.querySelectorAll('.cell')];
  const statusEl=document.getElementById('status');
  const modeEl=document.getElementById('mode');
  const diffWrap=document.getElementById('difficultyWrap');
  const diffEl=document.getElementById('difficulty');
  const markEl=document.getElementById('playerMark');
  const resetBtn=document.getElementById('reset');
  const tplX=document.getElementById('tplX');
  const tplO=document.getElementById('tplO');
  const LINES=[[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
  let state=Array(9).fill(null);
  let human="X", cpu="O", turn="X", gameOver=false;

  function setModeUI(){ diffWrap.style.display=(modeEl.value==='cpu')?'inline-flex':'none'; markEl.disabled=(modeEl.value==='pvp'); }
  function render(){ cells.forEach((c,i)=>{ c.innerHTML=""; c.classList.remove('win','lose'); const v=state[i]; if(v){ (v==='X'?tplX:tplO).content && c.appendChild((v==='X'?tplX:tplO).content.cloneNode(true)); c.setAttribute('aria-disabled','true'); } else { c.removeAttribute('aria-disabled'); } }); }
  function checkWinner(s){ for(const line of LINES){ const [a,b,c]=line; if(s[a]&&s[a]===s[b]&&s[a]===s[c]) return {winner:s[a], line}; } if(s.every(v=>v)) return {winner:'draw'}; return null; }
  const emptyIdx=s=> s.map((v,i)=>v?null:i).filter(i=>i!==null);
  function aiMoveEasy(s){ const e=emptyIdx(s); return e[Math.floor(Math.random()*e.length)]; }
  function aiMoveNormal(s, ai, pl){
    for(const i of emptyIdx(s)){ const t=s.slice(); t[i]=ai; if(checkWinner(t)?.winner===ai) return i; }
    for(const i of emptyIdx(s)){ const t=s.slice(); t[i]=pl; if(checkWinner(t)?.winner===pl) return i; }
    if(!s[4]) return 4;
    const corners=[0,2,6,8].filter(i=>!s[i]); if(corners.length) return corners[Math.floor(Math.random()*corners.length)];
    return aiMoveEasy(s);
  }
  function minimax(s, player, ai, pl){
    const res=checkWinner(s);
    if(res){ if(res.winner===ai) return {score:10}; if(res.winner===pl) return {score:-10}; return {score:0}; }
    const moves=[];
    for(const i of emptyIdx(s)){ const n=s.slice(); n[i]=player; const r=minimax(n, player===ai?pl:ai, ai, pl); moves.push({idx:i, score:r.score}); }
    if(player===ai){ let max=-1e9, mv=null; for(const m of moves){ if(m.score>max){ max=m.score; mv=m; } } return mv; }
    else { let min=1e9, mv=null; for(const m of moves){ if(m.score<min){ min=m.score; mv=m; } } return mv; }
  }
  function aiPick(){ const s=state.slice(); const ai=cpu, pl=human; const d=diffEl.value;
    if(d==='easy') return aiMoveEasy(s);
    if(d==='normal') return aiMoveNormal(s, ai, pl);
    const mv=minimax(s, ai, ai, pl); return mv?.idx;
  }
  function place(i, who){
    if(gameOver || state[i]) return false;
    state[i]=who; turn=(who==='X')?'O':'X'; render();
    const res=checkWinner(state);
    if(res){ gameOver=true; if(res.winner==='draw') statusEl.textContent='Draw!'; else { statusEl.textContent=`${res.winner} wins!`; for(const j of res.line){ cells[j].classList.add('win'); } } return true; }
    statusEl.textContent=(modeEl.value==='cpu' && turn===cpu)?'Computer thinking…':`${turn}'s turn.`;
    return true;
  }
  function handleCell(e){
    const idx=+e.currentTarget.dataset.i;
    if(modeEl.value==='pvp'){ place(idx, turn); }
    else { if(!place(idx, human)) return; if(!gameOver){ setTimeout(()=>{ const aiIdx=aiPick(); if(aiIdx!=null) place(aiIdx, cpu); }, 120); } }
  }
  function reset(){
    state=Array(9).fill(null); gameOver=false; const userMark=markEl.value;
    human=userMark; cpu=(userMark==='X')?'O':'X'; turn='X'; render();
    statusEl.textContent=(modeEl.value==='cpu' && human==='O')?'Computer starts…':'Your turn.';
    if(modeEl.value==='cpu' && human==='O'){ setTimeout(()=>{ const aiIdx=aiPick(); if(aiIdx!=null) place(aiIdx, cpu); }, 120); }
  }
  cells.forEach(c=>c.addEventListener('click', handleCell));
  resetBtn.addEventListener('click', reset);
  modeEl.addEventListener('change', ()=>{ setModeUI(); reset(); });
  diffEl.addEventListener('change', ()=>{});
  markEl.addEventListener('change', reset);
  setModeUI(); reset();
})();